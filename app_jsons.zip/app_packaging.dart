import 'dart:convert';
import 'package:flutter/services.dart';

class PackageConfigLoader {
  static Future<PackageConfig> loadAppConfig() async {
    String jsonString =
        await rootBundle.loadString("assets/config/app_packaging.json");
    Map<String, dynamic> jsonMap = json.decode(jsonString);
    return PackageConfig.fromJson(jsonMap);
  }
}

class PackageConfig {
  final String appName;
  final String packageName;
  final String version;
  final int buildNumber;
  final String environment;

  PackageConfig({
    required this.appName,
    required this.packageName,
    required this.version,
    required this.buildNumber,
    required this.environment,
  });

  factory PackageConfig.fromJson(Map<String, dynamic> json) {
    return PackageConfig(
      appName: json['appName'] ?? 'Flutter App',
      packageName: json['packageName'] ?? 'com.example.app',
      version: json['version'] ?? '1.0.0',
      buildNumber: json['buildNumber'] ?? 1,
      environment: json['environment'] ?? 'development',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'appName': appName,
      'packageName': packageName,
      'version': version,
      'buildNumber': buildNumber,
      'environment': environment,
    };
  }
}
