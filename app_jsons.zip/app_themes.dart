import 'package:flutter/material.dart';
import 'theme_constants.dart'; // If you have theme constants defined

class AppThemes {
  static ThemeData lightTheme(Map<String, dynamic>? themeConfigJson) {
    // Pass JSON config for overrides
    final base = ThemeData.light();
    return base.copyWith(
      primaryColor: themeConfigJson?['lightTheme']?['primaryColor'] != null
          ? Color(int.parse(themeConfigJson!['lightTheme']!['primaryColor']
              .replaceAll('#', '0xff')))
          : lightPrimaryColor, // Example of overriding from JSON
      colorScheme: base.colorScheme.copyWith(secondary: lightAccentColor),
      // backgroundColor: themeConfigJson?['lightTheme']?['backgroundColor'] !=
      //         null
      //     ? Color(int.parse(themeConfigJson!['lightTheme']!['backgroundColor']
      //         .replaceAll('#', '0xff')))
      //     : lightBackgroundColor,
      // ... other theme properties, potentially overridden from JSON
      textTheme: _lightTextTheme(
          base.textTheme,
          themeConfigJson?[
              'lightTheme']), // Example of text theme customization
      extensions: <ThemeExtension<dynamic>>[
        BrandColorThemeExtension(
          brandColor: themeConfigJson?['themeExtensions']?['brandColor'] != null
              ? Color(int.parse(
                  themeConfigJson!['themeExtensions']!['brandColor']
                      .replaceAll('#', '0xff')))
              : brandColorDefault, // Example for extension
        ),
      ],
    );
  }

  static ThemeData darkTheme(Map<String, dynamic>? themeConfigJson) {
    // Similar structure for dark theme with JSON overrides
    final base = ThemeData.dark();
    return base.copyWith(
      primaryColor: themeConfigJson?['darkTheme']?['primaryColor'] != null
          ? Color(int.parse(themeConfigJson!['darkTheme']!['primaryColor']
              .replaceAll('#', '0xff')))
          : darkPrimaryColor,
      colorScheme: base.colorScheme.copyWith(secondary: darkAccentColor),
      // darkBackgroundColor: darkBackgroundColor,
      textTheme: _darkTextTheme(base.textTheme),
      extensions: <ThemeExtension<dynamic>>[
        BrandColorThemeExtension(
          brandColor: themeConfigJson?['themeExtensions']?['brandColor'] != null
              ? Color(int.parse(
                  themeConfigJson!['themeExtensions']!['brandColor']
                      .replaceAll('#', '0xff')))
              : brandColorDefault,
        ),
      ],
    );
  }

  static TextTheme _lightTextTheme(
      TextTheme base, Map<String, dynamic>? themeConfigJson) {
    return base.apply(
      fontFamily: 'ProductSans', // Example - fixed font or from config
      displayColor: Colors.black87,
      bodyColor: Colors.black87,
    );
  }

  static TextTheme _darkTextTheme(TextTheme base) {
    return base.apply(
      fontFamily: 'ProductSans',
      displayColor: Colors.white,
      bodyColor: Colors.white,
    );
  }
}

// Example of a custom ThemeExtension (if used)
class BrandColorThemeExtension
    extends ThemeExtension<BrandColorThemeExtension> {
  final Color? brandColor;

  const BrandColorThemeExtension({
    this.brandColor,
  });

  @override
  BrandColorThemeExtension copyWith({Color? brandColor}) {
    return BrandColorThemeExtension(
      brandColor: brandColor ?? this.brandColor,
    );
  }

  @override
  ThemeExtension<BrandColorThemeExtension> lerp(
      covariant ThemeExtension<BrandColorThemeExtension>? other, double t) {
    if (other is! BrandColorThemeExtension) {
      return this;
    }
    return BrandColorThemeExtension(
      brandColor: Color.lerp(brandColor, other.brandColor, t),
    );
  }

  @override
  int get hashCode => brandColor.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is BrandColorThemeExtension &&
          runtimeType == other.runtimeType &&
          brandColor == other.brandColor;
}

// You might define constants in theme_constants.dart
const lightPrimaryColor = Colors.indigo;
const lightAccentColor = Colors.pinkAccent;
const lightBackgroundColor = Colors.grey;
