import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

class ThemeLoader {
  static Future<AppTheme> loadTheme() async {
    try {
      String jsonString =
          await rootBundle.loadString("assets/config/ui/theme.json");
      Map<String, dynamic> jsonMap = json.decode(jsonString);
      return AppTheme.fromJson(jsonMap);
    } catch (e) {
      debugPrint("Error loading theme: $e");
      return AppTheme.defaultTheme();
    }
  }
}

class AppTheme {
  final String themeName;
  final bool isDarkTheme;
  final Color primaryColor;
  final Color accentColor;
  final Color backgroundColor;
  final Color textColor;
  final TextTheme textTheme;
  final ColorScheme colorScheme;
  final AppBarTheme appBarTheme;
  final ButtonThemeData buttonTheme;
  final IconThemeData iconTheme;
  final DividerThemeData dividerTheme;
  final InputDecorationTheme inputDecorationTheme;
  final CardTheme cardTheme;
  final FloatingActionButtonThemeData floatingActionButtonTheme;
  final SwitchThemeData switchTheme;
  final SliderThemeData sliderTheme;
  final SnackBarThemeData snackBarTheme;
  final CheckboxThemeData checkboxTheme;
  final RadioThemeData radioTheme;

  AppTheme({
    required this.themeName,
    required this.isDarkTheme,
    required this.primaryColor,
    required this.accentColor,
    required this.backgroundColor,
    required this.textColor,
    required this.textTheme,
    required this.colorScheme,
    required this.appBarTheme,
    required this.buttonTheme,
    required this.iconTheme,
    required this.dividerTheme,
    required this.inputDecorationTheme,
    required this.cardTheme,
    required this.floatingActionButtonTheme,
    required this.switchTheme,
    required this.sliderTheme,
    required this.snackBarTheme,
    required this.checkboxTheme,
    required this.radioTheme,
  });

  ThemeData toThemeData() {
    return ThemeData(
      brightness: isDarkTheme ? Brightness.dark : Brightness.light,
      primaryColor: primaryColor,
      colorScheme: colorScheme,
      textTheme: textTheme,
      appBarTheme: appBarTheme,
      buttonTheme: buttonTheme,
      iconTheme: iconTheme,
      dividerTheme: dividerTheme,
      inputDecorationTheme: inputDecorationTheme,
      cardTheme: cardTheme,
      floatingActionButtonTheme: floatingActionButtonTheme,
      switchTheme: switchTheme,
      sliderTheme: sliderTheme,
      snackBarTheme: snackBarTheme,
      checkboxTheme: checkboxTheme,
      radioTheme: radioTheme,
    );
  }

  factory AppTheme.fromJson(Map<String, dynamic> json) {
    bool isDark = json["isDarkTheme"] ?? false;
    return AppTheme(
      themeName: json["themeName"] ?? "DefaultTheme",
      isDarkTheme: isDark,
      primaryColor: _parseColor(json["primaryColor"]),
      accentColor: _parseColor(json["accentColor"]),
      backgroundColor: _parseColor(json["backgroundColor"]),
      textColor: _parseColor(json["textColor"]),
      textTheme: _parseTextTheme(json["textTheme"]),
      colorScheme: _parseColorScheme(json["colorScheme"], isDark),
      appBarTheme: _parseAppBarTheme(json["appBarTheme"]),
      buttonTheme: _parseButtonTheme(json["buttonTheme"]),
      iconTheme: _parseIconTheme(json["iconTheme"]),
      dividerTheme: _parseDividerTheme(json["dividerTheme"]),
      inputDecorationTheme:
          _parseInputDecorationTheme(json["inputDecorationTheme"]),
      cardTheme: _parseCardTheme(json["cardTheme"]),
      floatingActionButtonTheme:
          _parseFloatingActionButtonTheme(json["floatingActionButtonTheme"]),
      switchTheme: _parseSwitchTheme(json["switchTheme"]),
      sliderTheme: _parseSliderTheme(json["sliderTheme"]),
      snackBarTheme: _parseSnackBarTheme(json["snackBarTheme"]),
      checkboxTheme: _parseCheckboxTheme(json["checkboxTheme"]),
      radioTheme: _parseRadioTheme(json["radioTheme"]),
    );
  }

  static Color _parseColor(String? hexColor) {
    if (hexColor == null || hexColor.isEmpty) return Colors.black;
    return Color(int.parse(hexColor.replaceFirst("#", "0xFF")));
  }

  static TextTheme _parseTextTheme(Map<String, dynamic>? json) {
    return TextTheme(
      displayLarge: _parseTextStyle(json?["displayLarge"]),
      displayMedium: _parseTextStyle(json?["displayMedium"]),
      displaySmall: _parseTextStyle(json?["displaySmall"]),
      headlineLarge: _parseTextStyle(json?["headlineLarge"]),
      headlineMedium: _parseTextStyle(json?["headlineMedium"]),
      headlineSmall: _parseTextStyle(json?["headlineSmall"]),
      titleLarge: _parseTextStyle(json?["titleLarge"]),
      titleMedium: _parseTextStyle(json?["titleMedium"]),
      titleSmall: _parseTextStyle(json?["titleSmall"]),
      bodyLarge: _parseTextStyle(json?["bodyLarge"]),
      bodyMedium: _parseTextStyle(json?["bodyMedium"]),
      bodySmall: _parseTextStyle(json?["bodySmall"]),
      labelLarge: _parseTextStyle(json?["labelLarge"]),
      labelMedium: _parseTextStyle(json?["labelMedium"]),
      labelSmall: _parseTextStyle(json?["labelSmall"]),
    );
  }

  static TextStyle _parseTextStyle(Map<String, dynamic>? json) {
    return TextStyle(
      fontSize: json?["fontSize"]?.toDouble() ?? 14,
      fontWeight: _parseFontWeight(json?["fontWeight"]),
      color: _parseColor(json?["color"]),
    );
  }

  static FontWeight _parseFontWeight(String? weight) {
    switch (weight) {
      case "bold":
        return FontWeight.bold;
      case "medium":
        return FontWeight.w500;
      case "light":
        return FontWeight.w300;
      default:
        return FontWeight.normal;
    }
  }

  static ColorScheme _parseColorScheme(
      Map<String, dynamic>? json, bool isDark) {
    return ColorScheme(
      brightness: isDark ? Brightness.dark : Brightness.light,
      primary: _parseColor(json?["primary"]),
      secondary: _parseColor(json?["secondary"]),
      surface: _parseColor(json?["surface"]),
      background: _parseColor(json?["background"]),
      error: _parseColor(json?["error"]),
      onPrimary: _parseColor(json?["onPrimary"]),
      onSecondary: _parseColor(json?["onSecondary"]),
      onSurface: _parseColor(json?["onSurface"]),
      onBackground: _parseColor(json?["onBackground"]),
      onError: _parseColor(json?["onError"]),
    );
  }

  static AppBarTheme _parseAppBarTheme(Map<String, dynamic>? json) {
    return AppBarTheme(
      backgroundColor: _parseColor(json?["backgroundColor"]),
      titleTextStyle: TextStyle(
        fontSize: json?["titleTextStyle"]["fontSize"]?.toDouble() ?? 20,
        fontWeight: _parseFontWeight(json?["titleTextStyle"]["fontWeight"]),
        color: _parseColor(json?["titleTextStyle"]["color"]),
      ),
      iconTheme: IconThemeData(
        color: _parseColor(json?["iconTheme"]["color"]),
      ),
    );
  }

  static ButtonThemeData _parseButtonTheme(Map<String, dynamic>? json) {
    return ButtonThemeData(
      buttonColor: _parseColor(json?["buttonColor"]),
      textTheme: ButtonTextTheme.primary,
    );
  }

  static IconThemeData _parseIconTheme(Map<String, dynamic>? json) {
    return IconThemeData(color: _parseColor(json?["color"]));
  }

  static DividerThemeData _parseDividerTheme(Map<String, dynamic>? json) {
    return DividerThemeData(color: _parseColor(json?["color"]));
  }

  static InputDecorationTheme _parseInputDecorationTheme(
      Map<String, dynamic>? json) {
    return InputDecorationTheme(fillColor: _parseColor(json?["fillColor"]));
  }

  static CardTheme _parseCardTheme(Map<String, dynamic>? json) {
    return CardTheme(color: _parseColor(json?["color"]));
  }

  static FloatingActionButtonThemeData _parseFloatingActionButtonTheme(
      Map<String, dynamic>? json) {
    return FloatingActionButtonThemeData(
        backgroundColor: _parseColor(json?["backgroundColor"]));
  }

  static SwitchThemeData _parseSwitchTheme(Map<String, dynamic>? json) {
    return SwitchThemeData(
        trackColor: WidgetStateProperty.all(_parseColor(json?["trackColor"])));
  }

  static SliderThemeData _parseSliderTheme(Map<String, dynamic>? json) {
    return SliderThemeData(
        activeTrackColor: _parseColor(json?["activeTrackColor"]));
  }

  static SnackBarThemeData _parseSnackBarTheme(Map<String, dynamic>? json) {
    return SnackBarThemeData(
        backgroundColor: _parseColor(json?["backgroundColor"]));
  }

  static CheckboxThemeData _parseCheckboxTheme(Map<String, dynamic>? json) {
    return CheckboxThemeData(
        fillColor: WidgetStateProperty.all(_parseColor(json?["fillColor"])));
  }

  static RadioThemeData _parseRadioTheme(Map<String, dynamic>? json) {
    return RadioThemeData(
        fillColor: WidgetStateProperty.all(_parseColor(json?["fillColor"])));
  }

  /// **Default Theme (Fallback)**
  static AppTheme defaultTheme() {
    return AppTheme(
      themeName: "DefaultTheme",
      isDarkTheme: false,
      primaryColor: Colors.blue,
      accentColor: Colors.pinkAccent,
      backgroundColor: Colors.white,
      textColor: Colors.black,
      textTheme: TextTheme(
        displayLarge: TextStyle(
            fontSize: 57, fontWeight: FontWeight.bold, color: Colors.black),
        displayMedium: TextStyle(
            fontSize: 45, fontWeight: FontWeight.w500, color: Colors.black),
        displaySmall: TextStyle(
            fontSize: 36, fontWeight: FontWeight.w400, color: Colors.black),
        headlineLarge: TextStyle(
            fontSize: 32, fontWeight: FontWeight.bold, color: Colors.blue),
        headlineMedium: TextStyle(
            fontSize: 28, fontWeight: FontWeight.w600, color: Colors.blue),
        headlineSmall: TextStyle(
            fontSize: 24, fontWeight: FontWeight.w500, color: Colors.blue),
        titleLarge: TextStyle(
            fontSize: 22, fontWeight: FontWeight.w500, color: Colors.black),
        titleMedium: TextStyle(
            fontSize: 16, fontWeight: FontWeight.w400, color: Colors.black),
        titleSmall: TextStyle(
            fontSize: 14, fontWeight: FontWeight.w300, color: Colors.black),
        bodyLarge: TextStyle(
            fontSize: 16, fontWeight: FontWeight.normal, color: Colors.black),
        bodyMedium: TextStyle(
            fontSize: 14, fontWeight: FontWeight.normal, color: Colors.black),
        bodySmall: TextStyle(
            fontSize: 12, fontWeight: FontWeight.normal, color: Colors.black),
        labelLarge: TextStyle(
            fontSize: 14, fontWeight: FontWeight.w500, color: Colors.blue),
        labelMedium: TextStyle(
            fontSize: 12, fontWeight: FontWeight.w400, color: Colors.blue),
        labelSmall: TextStyle(
            fontSize: 11, fontWeight: FontWeight.w300, color: Colors.blue),
      ),
      colorScheme: ColorScheme.light(),
      appBarTheme: AppBarTheme(backgroundColor: Colors.blue),
      buttonTheme: ButtonThemeData(buttonColor: Colors.blue),
      iconTheme: IconThemeData(color: Colors.black),
      dividerTheme: DividerThemeData(color: Colors.grey),
      inputDecorationTheme: InputDecorationTheme(fillColor: Colors.white),
      cardTheme: CardTheme(color: Colors.white),
      floatingActionButtonTheme:
          FloatingActionButtonThemeData(backgroundColor: Colors.blue),
      switchTheme:
          SwitchThemeData(trackColor: WidgetStateProperty.all(Colors.grey)),
      sliderTheme: SliderThemeData(activeTrackColor: Colors.blue),
      snackBarTheme: SnackBarThemeData(backgroundColor: Colors.black),
      checkboxTheme:
          CheckboxThemeData(fillColor: WidgetStateProperty.all(Colors.blue)),
      radioTheme:
          RadioThemeData(fillColor: WidgetStateProperty.all(Colors.blue)),
    );
  }
}
