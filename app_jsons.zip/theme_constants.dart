import 'package:flutter/material.dart';

// --- Light Theme Constants ---
const Color lightPrimaryColor = Colors.indigo;
const Color lightAccentColor = Colors.pinkAccent;
const Color lightBackgroundColor = Colors.grey; // Light grey background
const Color lightTextColorPrimary = Colors.black87;
const Color lightTextColorSecondary = Colors.grey;
const Color lightAppBarColor = Colors.indigo;
const Color lightCardColor = Colors.white;
const Color lightButtonColor = Colors.indigo;
const Color lightIconColor = Colors.black54;

// --- Dark Theme Constants ---
const Color darkPrimaryColor = Colors.blueGrey;
const Color darkAccentColor = Colors.tealAccent;
const Color darkBackgroundColor = Color(0xFF303030); // Dark grey background
const Color darkTextColorPrimary = Colors.white;
const Color darkTextColorSecondary = Colors.grey;
const Color darkAppBarColor = Colors.blueGrey;
const Color darkCardColor = Color(0xFF424242); // Slightly lighter dark card
const Color darkButtonColor = Colors.blueGrey;
const Color darkIconColor = Colors.white70;

// --- Common Theme Constants (if any, can be expanded) ---
const double defaultBorderRadius = 8.0;
const EdgeInsets defaultPadding = EdgeInsets.all(16.0);

// --- Brand Colors (Example Theme Extension - moved constants here for consistency) ---
const Color brandColorDefault =
    Colors.deepOrangeAccent; // Example default brand color
