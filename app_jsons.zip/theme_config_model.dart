import 'package:flutter/foundation.dart';

@immutable
class ThemeConfigModel {
  final String defaultTheme; // e.g., "light", "dark", "system"
  final Map<String, dynamic>? lightTheme;
  final Map<String, dynamic>? darkTheme;
  final Map<String, dynamic>? themeExtensions; // For custom theme extensions

  const ThemeConfigModel({
    required this.defaultTheme,
    this.lightTheme,
    this.darkTheme,
    this.themeExtensions,
  });

  factory ThemeConfigModel.fromJson(Map<String, dynamic> json) {
    return ThemeConfigModel(
      defaultTheme: _parseString(json['defaultTheme'], 'system', 'defaultTheme'),
      lightTheme: _parseMapOrNull(json['lightTheme'], 'lightTheme'),
      darkTheme: _parseMapOrNull(json['darkTheme'], 'darkTheme'),
      themeExtensions: _parseMapOrNull(json['themeExtensions'], 'themeExtensions'),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'defaultTheme': defaultTheme,
      'lightTheme': lightTheme,
      'darkTheme': darkTheme,
      'themeExtensions': themeExtensions,
    };
  }

    static String _parseString(dynamic value, String defaultValue, String fieldName) {
    if (value is String) {
      return value;
    }
    if (defaultValue.isNotEmpty) {
      debugPrint('Warning: ThemeConfigModel - Field "$fieldName" not found or invalid, using default value: "$defaultValue"');
      return defaultValue;
    }
    // Though default theme is important, 'system' is a reasonable fallback, so not throwing error for now
    debugPrint('Warning: ThemeConfigModel - Field "$fieldName" missing, using default value: "$defaultValue"');
    return defaultValue;
  }

  static Map<String, dynamic>? _parseMapOrNull(dynamic value, String fieldName) {
    if (value == null) {
      return null;
    }
    if (value is Map<String, dynamic>) {
      return value;
    }
    debugPrint('Warning: ThemeConfigModel - Expected Map for "$fieldName" but got ${value.runtimeType}. Using null.');
    return null;
  }


  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ThemeConfigModel &&
          runtimeType == other.runtimeType &&
          defaultTheme == other.defaultTheme &&
          mapEquals(lightTheme, other.lightTheme) &&
          mapEquals(darkTheme, other.darkTheme) &&
          mapEquals(themeExtensions, other.themeExtensions);

  @override
  int get hashCode =>
      defaultTheme.hashCode ^
      lightTheme.hashCode ^
      darkTheme.hashCode ^
      themeExtensions.hashCode;

  @override
  String toString() {
    return 'ThemeConfigModel{defaultTheme: $defaultTheme, lightTheme: $lightTheme, darkTheme: $darkTheme, themeExtensions: $themeExtensions}';
  }
}